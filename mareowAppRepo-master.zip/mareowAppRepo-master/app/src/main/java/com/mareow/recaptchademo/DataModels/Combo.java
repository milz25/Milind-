package com.mareow.recaptchademo.DataModels;

public class Combo {
}
