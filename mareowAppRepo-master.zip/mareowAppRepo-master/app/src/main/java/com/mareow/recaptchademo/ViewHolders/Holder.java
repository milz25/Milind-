package com.mareow.recaptchademo.ViewHolders;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class Holder extends RecyclerView.ViewHolder {

    public Holder(View itemView) {
        super(itemView);
    }
}
