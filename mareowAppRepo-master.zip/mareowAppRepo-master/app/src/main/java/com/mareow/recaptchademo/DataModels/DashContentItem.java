package com.mareow.recaptchademo.DataModels;


public class DashContentItem extends ListItem {

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    String name;
}
