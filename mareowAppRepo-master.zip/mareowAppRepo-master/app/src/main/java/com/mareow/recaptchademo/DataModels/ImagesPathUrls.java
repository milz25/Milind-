package com.mareow.recaptchademo.DataModels;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class ImagesPathUrls implements Serializable {
   /* @SerializedName("imagesPathUrls")
    @Expose
    List<String> imagesPathUrls;

    public List<String> getPaths() {
        return imagesPathUrls;
    }

    public void setPaths(List<String> paths) {
        this.imagesPathUrls = paths;
    }*/


}
