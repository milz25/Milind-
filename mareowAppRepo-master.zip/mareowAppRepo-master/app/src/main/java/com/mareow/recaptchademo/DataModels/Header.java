package com.mareow.recaptchademo.DataModels;

public class Header extends ListItem {
    private String header;

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

}
